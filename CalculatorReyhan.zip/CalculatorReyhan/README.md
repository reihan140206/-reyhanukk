# ScientificCalculator

This is a scientific calculator capable of doing basic scientific calculations.

## Screenshots:

<img src="/screenshots/calculator_1.png" width="360px"/> <img src="/screenshots/calculator_2.png" width="360px"/>

## Project Information:

**Language:**  Java<br>
**Tools:** Swing, mXparser Library<br>
**IDE:**  NetBeans IDE 8.2
